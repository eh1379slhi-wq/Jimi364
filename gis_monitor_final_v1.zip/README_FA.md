# سامانه پایش جغرافیایی و تحلیل گزارش‌های عمومی – نسخه نهایی آزمایشی

## قابلیت‌ها
- داشبورد واکنش‌گرا برای مرورگر اندروید
- نقشه تجمیعی در سطح استان (نشانگرها فقط مرکز تقریبی استان و شمار گزارش‌ها هستند)
- فیلتر استان، نوع گزارش، وضعیت راستی‌آزمایی و جست‌وجوی متنی
- خط زمانی انتشار و نمودار توزیع موضوعی
- ثبت دستی گزارش عمومی با تاریخ وقوع/انتشار جداگانه
- ورود گروهی CSV و XLSX
- خروجی CSV و پشتیبان Excel
- ثبت رویدادهای مدیریتی در جدول audit
- امکان فعال‌سازی رمز عبور از طریق متغیر محیطی GIS_APP_PASSWORD

## نصب و اجرا
Python 3.10+:
    python -m venv .venv
Windows:
    .venv\Scripts\activate
Linux/macOS:
    source .venv/bin/activate
سپس:
    pip install -r requirements.txt
    streamlit run app.py

برای دسترسی گوشی در یک شبکه Wi-Fi:
    streamlit run app.py --server.address 0.0.0.0
آدرس Network URL را در مرورگر اندروید وارد کنید.

## فعال‌سازی رمز عبور
Linux/macOS:
    export GIS_APP_PASSWORD='یک-رمز-قوی'
Windows PowerShell:
    $env:GIS_APP_PASSWORD='یک-رمز-قوی'
سپس برنامه را اجرا کنید. برای میزبانی عمومی، HTTPS و تنظیمات امنیتی سرور ضروری است.

## قالب ورود اطلاعات
ستون‌های مورد استفاده:
`region`, `district`, `subject`, `event_type`, `event_date`, `published_date`, `summary`, `source_name`, `source_type`, `source_url`, `verification`, `corroboration`, `analyst_note`, `recorded_at`

## نکات مهم
- داده‌های اولیه برنامه کاملاً ساختگی‌اند.
- ستون‌های latitude و longitude و مختصات دقیق پذیرفته یا نمایش داده نمی‌شوند.
- برنامه برای تحلیل راهبردیِ منابع علنی و گزارش‌های تاریخی/تجمیعی است؛ نه ردیابی زنده، هدف‌یابی یا تحلیل مسیرهای عملیاتی.
- بانک اطلاعاتی `gis_monitor.db` را به‌طور منظم پشتیبان‌گیری کنید.
