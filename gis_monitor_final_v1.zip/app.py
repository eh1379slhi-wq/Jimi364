import os
import sqlite3
from datetime import date, datetime
from io import BytesIO

import pandas as pd
import streamlit as st
import folium
from streamlit_folium import st_folium

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "gis_monitor.db")

st.set_page_config(page_title="سامانه پایش جغرافیایی", page_icon="🛰️", layout="wide")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700&display=swap');
html, body, [class*="css"] { direction: rtl; text-align: right; font-family: Vazirmatn, sans-serif; }
.stApp { background: #0b1220; color: #e5e7eb; }
.block-container { padding-top: 1.1rem; max-width: 1500px; }
div[data-testid="stMetric"] { background:#111c2e; border:1px solid #26364d; padding:12px; border-radius:12px; }
section[data-testid="stSidebar"] { background:#101a2b; }
</style>
""", unsafe_allow_html=True)

st.title("🛰️ سامانه پایش جغرافیایی و تحلیل گزارش‌های عمومی")
st.caption("نسخه نهایی آزمایشی · پایش منبع‌محور، تاریخی و تجمیعی در سطح استان و شهرستان")

# Broad administrative reference points only. These are not incident coordinates.
REGIONS = {
    "آذربایجان غربی": (37.55, 45.05),
    "آذربایجان شرقی": (38.08, 46.29),
    "کردستان": (35.31, 46.99),
    "کرمانشاه": (34.31, 47.07),
    "اردبیل": (38.25, 48.30),
    "زنجان": (36.67, 48.50),
    "ایلام": (33.64, 46.42),
}
EVENT_TYPES = [
    "خبر و گزارش رسانه‌ای", "بیانیه یا موضع‌گیری عمومی",
    "تحلیل سیاسی/امنیتی منتشرشده", "رویداد تاریخی",
    "گزارش عمومی امنیتی", "گزارش انسانی/اجتماعی", "سایر"
]
VERIFICATION = ["تأییدنشده", "در دست بررسی", "تأیید چندمنبعی", "تکذیب‌شده", "نامشخص"]
SOURCE_TYPES = ["رسانه رسمی", "خبرگزاری", "رسانه محلی", "گزارش سازمانی/پژوهشی", "شبکه اجتماعی", "سایر"]
COLS = [
    "region", "district", "subject", "event_type", "event_date", "published_date",
    "summary", "source_name", "source_type", "source_url", "verification",
    "corroboration", "analyst_note", "recorded_at"
]
LABELS = {
    "region":"استان/منطقه", "district":"شهرستان (اختیاری)", "subject":"عنوان یا موضوع",
    "event_type":"نوع گزارش", "event_date":"تاریخ وقوع", "published_date":"تاریخ انتشار",
    "summary":"خلاصه بی‌طرفانه", "source_name":"نام منبع", "source_type":"نوع منبع",
    "source_url":"پیوند مستقیم", "verification":"وضعیت راستی‌آزمایی",
    "corroboration":"منابع مستقل پشتیبان", "analyst_note":"یادداشت تحلیلی",
    "recorded_at":"زمان ثبت"
}

def connect():
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.execute("""CREATE TABLE IF NOT EXISTS reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        region TEXT, district TEXT, subject TEXT, event_type TEXT,
        event_date TEXT, published_date TEXT, summary TEXT,
        source_name TEXT, source_type TEXT, source_url TEXT,
        verification TEXT, corroboration TEXT, analyst_note TEXT, recorded_at TEXT
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT, item_id INTEGER, timestamp TEXT
    )""")
    con.commit()
    return con

def get_data():
    con = connect()
    d = pd.read_sql_query("SELECT " + ",".join(COLS) + " FROM reports ORDER BY published_date DESC", con)
    con.close()
    return d

def log_action(action, item_id=None):
    con = connect()
    con.execute("INSERT INTO audit(action,item_id,timestamp) VALUES(?,?,?)",
                (action, item_id, datetime.now().isoformat(timespec="seconds")))
    con.commit()
    con.close()

def add_frame(frame):
    frame = frame.copy()
    for c in COLS:
        if c not in frame.columns:
            frame[c] = ""
    frame = frame[COLS].fillna("")
    # Do not import or accept coordinates: display is aggregated by administrative area.
    frame = frame.drop(columns=[], errors="ignore")
    con = connect()
    for _, row in frame.iterrows():
        vals = [str(row[c]) for c in COLS]
        con.execute("INSERT INTO reports(" + ",".join(COLS) + ") VALUES(" + ",".join(["?"]*len(COLS)) + ")", vals)
        con.execute("INSERT INTO audit(action,item_id,timestamp) VALUES(?,?,?)",
                    ("ثبت گزارش", None, datetime.now().isoformat(timespec="seconds")))
    con.commit()
    con.close()

def seed():
    d = get_data()
    if d.empty:
        demo = pd.DataFrame([
            ["آذربایجان غربی","نمونه شهرستان","نمونه آموزشی ۱",EVENT_TYPES[0],"2026-10-28","2026-10-29",
             "داده ساختگی برای آزمایش داشبورد؛ هیچ رویداد واقعی را توصیف نمی‌کند.",
             "منبع آزمایشی",SOURCE_TYPES[-1],"",VERIFICATION[0],"","صرفاً داده نمایشی","2026-11-10"],
            ["کردستان","نمونه شهرستان","نمونه آموزشی ۲",EVENT_TYPES[3],"2026-10-25","2026-10-26",
             "رکورد تاریخی کاملاً ساختگی برای آزمایش فیلتر و خط زمانی.",
             "منبع آزمایشی",SOURCE_TYPES[-1],"",VERIFICATION[1],"","مکان دقیق ثبت نشده است","2026-11-10"],
            ["آذربایجان شرقی","","نمونه آموزشی ۳",EVENT_TYPES[1],"2026-10-20","2026-10-21",
             "نمونه غیرواقعی؛ برای نمایش وضعیت چندمنبعی و جدول.",
             "منبع آزمایشی",SOURCE_TYPES[-1],"",VERIFICATION[2],"دو منبع فرضی","داده نمونه","2026-11-10"]
        ], columns=COLS)
        add_frame(demo)
seed()

# Optional simple access gate. Set GIS_APP_PASSWORD in the hosting environment.
password = os.environ.get("GIS_APP_PASSWORD", "")
if password:
    if "authenticated" not in st.session_state:
        st.session_state.authenticated = False
    if not st.session_state.authenticated:
        st.subheader("ورود به سامانه")
        entered = st.text_input("رمز عبور", type="password")
        if st.button("ورود"):
            if entered == password:
                st.session_state.authenticated = True
                st.rerun()
            else:
                st.error("رمز عبور نادرست است.")
        st.stop()

df = get_data()

with st.sidebar:
    st.header("فیلترهای پایش")
    regions = sorted(df.region.dropna().astype(str).unique().tolist())
    region_filter = st.multiselect("استان/منطقه", regions, default=regions)
    types = sorted(df.event_type.dropna().astype(str).unique().tolist())
    type_filter = st.multiselect("نوع گزارش", types, default=types)
    statuses = sorted(df.verification.dropna().astype(str).unique().tolist())
    status_filter = st.multiselect("اعتبارسنجی", statuses, default=statuses)
    text_filter = st.text_input("جست‌وجو در عنوان و خلاصه")
    st.divider()
    st.caption("نمایش جغرافیایی فقط تجمیعی و اداری است. مختصات افراد، یگان‌ها، پایگاه‌ها، مسیرها یا اهداف در این سامانه ثبت یا نمایش داده نمی‌شود.")

f = df.copy()
if region_filter: f = f[f.region.isin(region_filter)]
if type_filter: f = f[f.event_type.isin(type_filter)]
if status_filter: f = f[f.verification.isin(status_filter)]
if text_filter:
    mask = f.subject.fillna("").str.contains(text_filter, case=False) | f.summary.fillna("").str.contains(text_filter, case=False)
    f = f[mask]

# KPI strip
k1,k2,k3,k4 = st.columns(4)
k1.metric("کل گزارش‌های فیلترشده", len(f))
k2.metric("مناطق دارای گزارش", f.region.nunique() if len(f) else 0)
k3.metric("تأیید چندمنبعی", int((f.verification == "تأیید چندمنبعی").sum()))
k4.metric("در دست بررسی", int((f.verification == "در دست بررسی").sum()))

t_overview, t_map, t_records, t_add, t_import, t_sources, t_admin = st.tabs([
    "نمای کلی", "نقشه GIS", "بانک گزارش‌ها", "ثبت گزارش", "ورود/خروج داده",
    "ارزیابی منابع", "مدیریت و راهنما"
])

with t_overview:
    st.subheader("نمای کلی وضعیت گزارش‌های عمومی")
    if len(f):
        by_type = f.groupby("event_type").size().sort_values(ascending=False).rename("تعداد")
        st.write("**توزیع موضوعی**")
        st.bar_chart(by_type)
        timeline = f.copy()
        timeline["تاریخ انتشار"] = pd.to_datetime(timeline.published_date, errors="coerce")
        timeline = timeline.dropna(subset=["تاریخ انتشار"]).groupby("تاریخ انتشار").size().rename("تعداد گزارش")
        if len(timeline):
            st.write("**روند انتشار گزارش‌ها**")
            st.line_chart(timeline)
        st.write("**آخرین گزارش‌های ثبت‌شده**")
        st.dataframe(f.sort_values("published_date", ascending=False)[["region","subject","event_type","published_date","verification","source_name"]].rename(columns=LABELS), use_container_width=True, hide_index=True)
    else:
        st.info("برای فیلترهای فعلی داده‌ای وجود ندارد.")

with t_map:
    st.subheader("نقشه تجمیعی استان‌ها")
    st.warning("هر نشانگر فقط شمار گزارش‌های ثبت‌شده در یک استان را نشان می‌دهد؛ نشانگر، محل وقوع یا موقعیت عملیاتی نیست.")
    m = folium.Map(location=[36.4,46.8], zoom_start=6, tiles="CartoDB dark_matter")
    counts = f.groupby("region").size().to_dict() if len(f) else {}
    for name, count in counts.items():
        if name in REGIONS:
            lat, lon = REGIONS[name]
            folium.CircleMarker([lat,lon], radius=7+min(count,15), color="#38bdf8",
                fill=True, fill_color="#0ea5e9", fill_opacity=.72,
                tooltip=f"{name} · {count} گزارش",
                popup=f"{name}: {count} گزارش تجمیعی").add_to(m)
    st_folium(m, use_container_width=True, height=560)

with t_records:
    st.subheader("بانک اطلاعاتی")
    if len(f):
        display = f.copy().rename(columns=LABELS)
        st.dataframe(display, use_container_width=True, hide_index=True)
        st.download_button("دانلود CSV فیلترشده", f.to_csv(index=False).encode("utf-8-sig"),
                           "public_reports_filtered.csv", "text/csv")
    else:
        st.info("رکوردی یافت نشد.")

with t_add:
    st.subheader("ثبت یک گزارش عمومی")
    with st.form("new_report", clear_on_submit=True):
        c1,c2 = st.columns(2)
        region = c1.selectbox("استان/منطقه", list(REGIONS.keys()))
        district = c2.text_input("شهرستان (اختیاری)")
        subject = c1.text_input("عنوان یا موضوع")
        event_type = c2.selectbox("نوع گزارش", EVENT_TYPES)
        event_date = c1.date_input("تاریخ وقوع", date.today())
        published_date = c2.date_input("تاریخ انتشار", date.today())
        summary = st.text_area("خلاصه بی‌طرفانه گزارش", max_chars=1800)
        c3,c4 = st.columns(2)
        source_name = c3.text_input("نام منبع")
        source_type = c4.selectbox("نوع منبع", SOURCE_TYPES)
        source_url = st.text_input("پیوند مستقیم منبع")
        verification = st.selectbox("وضعیت راستی‌آزمایی", VERIFICATION)
        corroboration = st.text_input("منابع مستقل پشتیبان (در صورت وجود)")
        analyst_note = st.text_area("یادداشت تحلیلی غیرعملیاتی", max_chars=1000)
        ok = st.form_submit_button("ذخیره گزارش")
        if ok:
            if not subject.strip() or not summary.strip() or not source_name.strip():
                st.error("عنوان، خلاصه و نام منبع الزامی است.")
            else:
                row = pd.DataFrame([{
                    "region":region,"district":district,"subject":subject,"event_type":event_type,
                    "event_date":event_date.isoformat(),"published_date":published_date.isoformat(),
                    "summary":summary,"source_name":source_name,"source_type":source_type,
                    "source_url":source_url,"verification":verification,
                    "corroboration":corroboration,"analyst_note":analyst_note,
                    "recorded_at":datetime.now().isoformat(timespec="seconds")
                }])
                add_frame(row)
                st.success("گزارش ذخیره شد. برای مشاهده، صفحه را تازه‌سازی کنید.")

with t_import:
    st.subheader("ورود و خروج گروهی")
    st.write("فایل CSV یا XLSX با نام ستون‌های انگلیسی زیر وارد کنید:")
    st.code(", ".join(COLS))
    up = st.file_uploader("انتخاب فایل CSV یا Excel", type=["csv","xlsx"])
    if up:
        try:
            incoming = pd.read_csv(up) if up.name.lower().endswith(".csv") else pd.read_excel(up)
            st.dataframe(incoming.head(15), use_container_width=True)
            st.caption("ستون‌های اضافی مانند latitude/longitude نادیده گرفته می‌شوند؛ داده مکانی دقیق پذیرفته نمی‌شود.")
            if st.button("تأیید و افزودن فایل"):
                for col in COLS:
                    if col not in incoming.columns: incoming[col] = ""
                incoming = incoming[COLS].fillna("").astype(str)
                incoming = incoming[incoming["summary"].str.strip() != ""]
                add_frame(incoming)
                st.success(f"{len(incoming)} رکورد وارد شد.")
        except Exception as e:
            st.error(f"خطا در خواندن فایل: {e}")
    st.divider()
    all_data = get_data()
    st.download_button("پشتیبان کامل CSV", all_data.to_csv(index=False).encode("utf-8-sig"),
                       "gis_database_backup.csv", "text/csv")
    xbuf = BytesIO()
    with pd.ExcelWriter(xbuf, engine="openpyxl") as writer:
        all_data.to_excel(writer, index=False, sheet_name="Reports")
    st.download_button("پشتیبان کامل Excel", xbuf.getvalue(), "gis_database_backup.xlsx",
                       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

with t_sources:
    st.subheader("ارزیابی کیفیت منبع")
    st.markdown("""
    برای هر گزارش این موارد را بررسی کنید:
    1. منبع اصلی خبر چیست و آیا لینک مستقیم به مطلب وجود دارد؟
    2. تاریخ وقوع با تاریخ انتشار اشتباه نشده است؟
    3. آیا رسانه‌های مستقل دیگر همان ادعا را تأیید کرده‌اند؟
    4. آیا متن خبر، واقعیت مشاهده‌شده را از ادعا یا تحلیل جدا می‌کند؟
    5. آیا اصلاحیه، تکذیب یا به‌روزرسانی بعدی منتشر شده است؟

    برچسب «تأیید چندمنبعی» فقط زمانی انتخاب شود که چند منبع مستقل، اصل ادعا را جداگانه تأیید کرده باشند. تعداد منابع به‌تنهایی تضمین صحت نیست.
    """)
    if len(f):
        st.dataframe(f[["subject","source_name","source_type","source_url","verification","corroboration"]].rename(columns=LABELS), use_container_width=True, hide_index=True)

with t_admin:
    st.subheader("مدیریت داده و ملاحظات")
    st.markdown("""
    **محدودیت‌های طراحی‌شده برای استفاده مسئولانه**
    - این سامانه برای تحلیل راهبردیِ مبتنی بر منابع علنی، تاریخچه و آمار تجمیعی است.
    - مختصات دقیق افراد، گروه‌ها، یگان‌ها، تأسیسات، مسیرهای حرکت یا نقاط آسیب‌پذیر ثبت و نمایش داده نمی‌شود.
    - هیچ قابلیت ردیابی زنده، پیش‌بینی تحرک، تعیین هدف یا پیشنهاد اقدام عملیاتی وجود ندارد.
    - داده‌های اولیه ساختگی‌اند و نباید به‌عنوان خبر واقعی استناد شوند.

    **حفاظت از داده**
    - فایل `gis_monitor.db` بانک اطلاعاتی محلی است؛ مرتب از آن کپی پشتیبان بگیرید.
    - برای استفاده شبکه‌ای، رمز عبور را با متغیر محیطی `GIS_APP_PASSWORD` تنظیم کنید و برنامه را پشت HTTPS اجرا کنید.
    - رمز ساده داخل کد قرار ندهید و پورت برنامه را بدون احراز هویت روی اینترنت عمومی باز نکنید.

    **اجرای روی اندروید**
    این نسخه یک داشبورد وب واکنش‌گراست. پایتون روی رایانه یا سرور اجرا می‌شود و گوشی با مرورگر به آن متصل می‌شود؛ APK مستقل نیست.
    """)
    con = connect()
    audit = pd.read_sql_query("SELECT * FROM audit ORDER BY timestamp DESC LIMIT 100", con)
    con.close()
    st.write("**آخرین ۱۰۰ عملیات ثبت‌شده**")
    st.dataframe(audit, use_container_width=True, hide_index=True)
